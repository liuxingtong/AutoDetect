# AutoDetect 复现资料包

本资料包整理了录音转写和 2026-09-29 完成的 AutoDetect 小规模复现。

## 推荐阅读顺序

1. [录音完整转写](录音完整转写.md)
2. [运行报告（中文可读版）](运行报告-中文可读版.md)
3. [论文原始结果 vs 本次复现](论文原始结果-vs-本次复现.md)
4. [迭代汇总（中文可读版）](迭代汇总-中文可读版.md)
5. [逐样本记录（中文可读版）](逐样本记录-中文可读版.md)

## 原始数据

- [原始运行报告](report.md)
- [原始逐样本 JSONL](samples.jsonl)
- [原始迭代 CSV](iterations.csv)
- [原始指标 CSV](metrics.csv)
- [运行清单](manifest.json)
- [迭代趋势图](score_by_iteration.png)

录音转写在本机离线完成；实验原始数据从服务器结果目录复制而来，未修改原始 JSONL/CSV。
